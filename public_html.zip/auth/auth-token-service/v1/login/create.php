<?php
// Proxy to the actual create.php
require_once __DIR__ . '/../../../../../auth-token-service/v1/login/create.php';
?>