<?php
echo "PHP is working!";
echo "<br>Current directory: " . __DIR__;
echo "<br>Document root: " . $_SERVER['DOCUMENT_ROOT'];
echo "<br>Request URI: " . $_SERVER['REQUEST_URI'];
?>