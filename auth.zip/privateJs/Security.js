function Host(){
    return location.hostname;
}