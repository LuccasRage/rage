<?php
require('../../setup.php');
?>
{
    "primaryMediaType": "<?=$twoStepVerificationType;?>",
    "methods": [
        {
            "mediaType": "Email",
            "enabled": true,
            "updated": null
        },
        {
            "mediaType": "Authenticator",
            "enabled": true,
            "updated": null
        },
        {
            "mediaType": "RecoveryCode",
            "enabled": true,
            "updated": null
        },
        {
            "mediaType": "SMS",
            "enabled": true,
            "updated": null
        },
        {
            "mediaType": "SecurityKey",
            "enabled": false,
            "updated": null
        }
    ]
}