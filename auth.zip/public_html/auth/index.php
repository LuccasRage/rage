<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

$requestUri = $_SERVER['REQUEST_URI'];
$path = parse_url($requestUri, PHP_URL_PATH);

// Debug logging
error_log("Auth Router - Method: " . $_SERVER['REQUEST_METHOD'] . " Path: " . $path);

// Handle v1/metadata specifically
if (strpos($path, '/v1/metadata') !== false) {
    echo json_encode([
        'twoStepVerificationEnabled' => true,
        'authenticatorEnabled' => true,
        'emailEnabled' => true,
        'smsEnabled' => false,
        'recoveryCodeEnabled' => false
    ]);
    exit;
}

// Handle v2/login
if (strpos($path, '/v2/login') !== false) {
    error_log("Routing to v2/login.php");
    require_once __DIR__ . '/v2/login.php';
    exit;
}

// Handle v2/step
if (strpos($path, '/v2/step') !== false) {
    require_once __DIR__ . '/v2/step.php';
    exit;
}

// Handle 2FA verification endpoints
if (preg_match('/\/v1\/users\/(\d+)\/challenges\/(.+)\/verify/', $path)) {
    require_once __DIR__ . '/v2/step.php';
    exit;
}

// Handle test endpoint
if (strpos($path, '/test') !== false) {
    echo json_encode([
        'status' => 'Auth router working',
        'path' => $path,
        'method' => $_SERVER['REQUEST_METHOD'],
        'query' => $_SERVER['QUERY_STRING'] ?? '',
        'body' => file_get_contents('php://input')
    ]);
    exit;
}

http_response_code(404);
echo json_encode([
    'error' => 'Endpoint not found',
    'path' => $path,
    'method' => $_SERVER['REQUEST_METHOD'],
    'available_endpoints' => [
        '/v1/metadata',
        '/v2/login', 
        '/v2/step',
        '/v1/users/{id}/challenges/{type}/verify'
    ]
]);
?>