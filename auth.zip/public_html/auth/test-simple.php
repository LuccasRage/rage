<?php
echo "Auth folder is accessible!";
echo "<br>Current directory: " . __DIR__;
echo "<br>Files in this directory: ";
print_r(scandir(__DIR__));
?>