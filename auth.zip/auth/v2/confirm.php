<?php

echo json_encode(['status' => 'success', 'message' => 'Response received successfully.']);
?>
